//
// Sprites
//

#include <lib.h>

struct RetourTouche { 
    int x; 
	int y;
	char flag;
};

typedef struct RetourTouche RetourTouche;

extern unsigned char LabelPicture[];
extern unsigned char CachePicture[];

extern unsigned char PGS_putspriteref(unsigned char NumSprite, unsigned char SpriteToDisplay, unsigned char x, unsigned char y);
extern unsigned char PGS_putsprite(unsigned char NumSprite, unsigned char SpriteToDisplay, unsigned char x, unsigned char y);
extern unsigned char PGS_puttile(unsigned char SpriteToDisplay, unsigned char x, unsigned char y);
extern unsigned char PGS_erasprite(unsigned char NumSprite);

extern unsigned char 		PGS_refreshscr();
extern unsigned char 		PGS_initsprite();

extern void				delai(unsigned char ttime);

RetourTouche r;

char teste_touches(int x, int y, int dx, int dy, int x1, int x2, int y1, int y2){
	char a;
	
	a=key();
	r.flag = 1;r.x=0;r.y=0;
	if(a==  'Q' || a=='A') { r.flag=0; } else
	if(a==  'L' && x<x2 ) { r.x=dx; } else
	if(a==  'J' && x>x1 ) { r.x=-dx; } else
	if(a==  'K' && y<y2 ) { r.y=dy; } else
	if(a==  'I' && y>y1 ) { r.y=-dy; } else
	if(a==  'O' && y>y1 && x<x2) { r.y=-dy; r.x=dx; } else
	if(a==  'U' && y>y1 && x>x1) { r.y=-dy; r.x=-dx; } else
	if(a==  'M' && y<y2 && x>x1) { r.y=dy; r.x=-dx; } else
	if(a==  '.' && y<y2 && x<x2) { r.y=dy; r.x=dx; };
	return a;
}

void dessine_decor(){
	int x,y;
	int x0,y0;
	char a;
	
	x=20; y=80;
	x0=-1; y0=-1;
	
	do{
		a=teste_touches(x,y,1,1,0,35,0,160);
		x+=r.x;
		y+=r.y;
		PGS_putsprite(3,3,x,y); 
		PGS_refreshscr();		

		if(a == 'S'){
			PGS_erasprite(3);
			PGS_puttile(4,x,y);
			PGS_refreshscr();
		}
		
	}while(r.flag);
	r.flag = 1;

}

void main()
{
	int i;
	int j;
	int x,y,x1,y1,x2,y2,dx,dy,dx1,dy1,dx2,dy2;
	char flagFin, flagM;
	char a;
	
	hires();
	memcpy((unsigned char*)0xa000,LabelPicture,8000);
	PGS_initsprite();
	memcpy((unsigned char*) CachePicture,LabelPicture,8000);

	x=0;
	y=0;
	x1=36;
	y1=0;
	x2=18;
	y2=96;
	dx=-1;
	dy=4;
	dx2=0;
	dy2=2;
	
	dx1=1;
	dy1=4;

	poke(0x26A,10);
	poke(0x24E,1);
	poke(0x24F,1);
	
	PGS_puttile(4,33,130);
	PGS_refreshscr();

	i=0;
	do {
		i++;
		a = teste_touches(x,y,1,4,0,35,0,160);
		if(a=='D'){
			PGS_erasprite(1);
			PGS_erasprite(2);
			PGS_erasprite(3);
			PGS_refreshscr();
			dessine_decor();
			delai(100);
			a=get();
			
		} else {
			
			x+=r.x;
			y+=r.y;
			PGS_putsprite(3,3,x,y); 
			PGS_putsprite(1,1,x2,y2);
			PGS_putsprite(2,2,x1,y1);
			PGS_refreshscr();
			if(i>2){
				x2+=dx2;
				y2+=dy2;
				if(x2>35 || x2<0){x2 -= dx2; y2 -= dy2; dx2 = -dx2;}
				if(y2>161 || y2<0){y2 -= dy2; x2 -= dx2; dy2 = -dy2;}
				x1+=dx1;
				y1+=dy1;
				if(x1>35 || x1<0){x1 -= dx1; y1 -= dy1; dx1 = -dx1;}
				if(y1>161 || y1<0){y1 -= dy1; x1 -= dx1; dy1 = -dy1;}
				i=0;
			}
		}
	} while(r.flag);
	poke(0x26A,3);
	poke(0x24E,32);
	poke(0x24F,4);
	
}